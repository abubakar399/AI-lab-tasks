from flask import Flask, render_template, request
import pickle

app = Flask(__name__)
model = pickle.load(open('model_svr.pkl', 'rb'))

# Dropdown options
ship_modes = ['Same Day', 'First Class', 'Second Class', 'Standard Class']
segments = ['Consumer', 'Corporate', 'Home Office']
regions = ['South', 'West', 'Central', 'East']
categories = ['Furniture', 'Office Supplies', 'Technology']

@app.route('/')
def home():
    return render_template('index.html',
                           ship_modes=ship_modes,
                           segments=segments,
                           regions=regions,
                           categories=categories)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        sales = float(request.form['Sales'])
        discount = float(request.form['Discount'])
        quantity = int(request.form.get('Quantity', 1))  # Quantity added

        # Get selected index (0,1,2,3)
        ship_mode = ship_modes.index(request.form['Ship Mode'])
        segment = segments.index(request.form['Segment'])
        region = regions.index(request.form['Region'])
        category = categories.index(request.form['Category'])

        # Final input array for model
        data = [1,881,229,149,ship_mode,127,147,segment,0,137,15,42420,region,12,category,0,sales,discount]
        pred = round(model.predict([data])[0], 2)

        return render_template('index.html',
                               prediction_text=f"Predicted Profit: ${pred:,}",
                               ship_modes=ship_modes, segments=segments,
                               regions=regions, categories=categories)
    except Exception as e:
        return render_template('index.html',
                               prediction_text="Please fill all fields correctly!",
                               ship_modes=ship_modes, segments=segments,
                               regions=regions, categories=categories)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000)